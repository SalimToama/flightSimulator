#ifndef PROJECT_COMMAND_H
#define PROJECT_COMMAND_H

#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
//#include <string.h>
using namespace std;
/*
 * interface for the interpreter.
 */
static mutex useMutex;

class Command {
public:
    // execute the specific command.
    virtual ~Command() = default;
    virtual void doCommand(vector<string> &operation) = 0;
};

#endif //PROJECT_COMMAND_H
