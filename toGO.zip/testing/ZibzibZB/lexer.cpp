//
// Created by issa on 12/17/18.
//


#include "lexer.h"

vector<string> lexer::lexerToTextFile(const string &lexer) {
    string allFile = "";
    vector<string> lines;
    fstream file;
    string lineFromText;
    string temp;
    if (!file.is_open()) {
        file.open(lexer, fstream::app | fstream::in);
    }
    while (getline(file, lineFromText)) {
        if (allFile != "")
            allFile.append(" ");
        allFile.append(lineFromText);
    }
    spacer(allFile);
    file.close();
    lines = splitLine(allFile);
    for (auto it = lines.begin();it !=lines.end();++it){
        cout << *it << endl;
    }
    return lines;
}

bool lexer::ifNumber(char ch) {
    return !(ch < '0' || ch > '9');
}

bool lexer::isLeftParentheses(char parentheses) {
    return parentheses == '(';
}

bool lexer::isOperator(char operation) {
    switch (operation) {
        case ',':
            return true;
        case '+':
            return true;
        case '-':
            return true;
        case '*':
            return true;
        case '/':
            return true;
        case '=':
            return true;
        case '<':
            return true;
        case '>':
            return true;
        case '!':
            return true;
        default:
            return false;
    }
}

bool lexer::isRightParentheses(char parnthese) {
    return parnthese == ')';
}

void lexer::spacer(string &st) {
    bool gersh = false;
    for (unsigned i = 0; i < st.length(); i++) {
        /*if (st[i] == ','){
            string rep = " ";
            rep.append(1, st[i]);
            st.replace(i++, 1, rep);
            continue;
        }  */
        if (!gersh && st[i] == '\"')
            gersh = true;
        else if (gersh && st[i] == '\"')
            gersh = false;
        // Spaces.
        if (st[i] == ' ') {
            continue;
        }
        // Operators And Brackets.
        if ((isOperator(st[i]) || isLeftParentheses(st[i]) || isRightParentheses(st[i])) && !gersh) {
            if (st.length() != i + 1 && ' ' != st[i + 1]) {
                string rep = " ";
                rep.append(1, st[i + 1]);
                st.replace(i + 1, 1, rep);
            }
            continue;
        }
        // Numbers.
        if (ifNumber(st[i])) {
            while (++i != st.length()) {
                if (!ifNumber(st[i]) && st[i] != '.' && !gersh) {
                    if (st[i] != ' ') {
                        string rep = " ";
                        rep.append(1, st[i]);
                        st.replace(i, 1, rep);
                    }
                    break;
                }
            }
            continue;
        }
            // Vars.
        else {
            while (++i != st.length()) {
                /*if (st[i] == ','){
                    string rep = " ";
                    rep.append(1, st[i]);
                    st.replace(i++, 1, rep);
                    break;
                }*/
                if (((isOperator(st[i]) || st[i] == ' ' || isRightParentheses(st[i])) && !gersh) ||
                    (st[i] == '\"' && gersh)) {
                    if (st[i] == '\"' && gersh) {
                        i++;
                        gersh = false;
                    }
                    if (st[i] != ' ') {
                        string rep = " ";
                        rep.append(1, st[i]);
                        st.replace(i, 1, rep);
                    }
                    break;
                }
            }
            continue;
        }
    }
}

vector<string> lexer::splitLine(const string &line) {
    //function to split the line by spaces.
    stringstream splitter(line);
    istream_iterator<string> begin(splitter);
    istream_iterator<string> end;
    vector<string> vstrings(begin, end);
    return vstrings;
}

/*
 * vector <string> lines;
    fstream file;
    string lineFromText;
    if (!file.is_open()) {
        file.open(lexer, fstream::app | fstream::in);
    }
    while (file >> lineFromText) {
        lines.push_back(lineFromText);
    }
    file.close();
    return lines;
 */
/*
vector<string> lexer::manageStrings(const vector<string> &afterSpacer) {
    int i = 0;
    bool number = false, LeftOperation = false, action = false, rightOperation;
    int left = 0, right = 0;
    string expression;
    vector<string> temp;
    for (int i = 0; i < afterSpacer.size(); i++) {
        if (ifNumber(afterSpacer[i])) {

            if (number) {
                temp.push_back(expression);
                expression = "";
                continue;
            }
            //number = true;
            //action = false;
            expression += afterSpacer[i] + " ";
            continue;
        }
        if (isLeftParentheses(afterSpacer[i])) {
            if (left == right && left > 0) {
                temp.push_back(expression);
                expression = "";
                continue;
            }
            left++;
            //number = false;
            //action = false;
            expression += afterSpacer[i] + " ";
            continue;
        }
        if (isRightParentheses(afterSpacer[i])) {
            right++;
            if (left == right && left > 0) {
                action = true;
                expression += afterSpacer[i] + " ";
                temp.push_back(expression);
                expression = "";
                continue;
            }
            //number = false;
            //action = false;
            expression += afterSpacer[i] + " ";
            continue;
        }
        if (isOperator(afterSpacer[i])) {
            if (action) {
                expression += afterSpacer[i];
                temp.push_back(expression);
                expression = "";
                continue;
            }
            //action = true;
            //number = false;
            expression += afterSpacer[i] + " ";
            continue;
        }
        expression += afterSpacer[i] + " ";
        //number = false;
    }

}
*/
/*

*/