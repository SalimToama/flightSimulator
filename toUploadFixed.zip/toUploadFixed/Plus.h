//
// Created by issa on 12/10/18.
//

#ifndef PROJECT_PLUS_H
#define PROJECT_PLUS_H


#include "BinaryExpression.h"

class Plus : public BinaryExpression{
public:
    Plus(Expression *left, Expression *right);
    double calculate();

};


#endif //PROJECT_PLUS_H
