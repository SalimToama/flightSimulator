#ifndef PROJECT_CONNECTCOMAND_H
#define PROJECT_CONNECTCOMAND_H

#include "Command.h"
#include "dataBase.h"
#include <vector>
#include <regex>
class ConnectCommand :public Command{
    vector<string>::iterator &iterator1;
    dataBase *allMaps;
public:
    ConnectCommand(
            vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1,
            dataBase *allMaps);

    int doCommand(vector<string> text,int index);
};


#endif //PROJECT_CONNECTCOMAND_H
