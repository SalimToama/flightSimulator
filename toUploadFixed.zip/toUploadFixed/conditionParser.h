
#ifndef PROJECT_CONDITIONPARSER_H
#define PROJECT_CONDITIONPARSER_H


#include "Command.h"
/*
class conditionParser : public Command{
public:
    int doCommand(vector<string> operation,int index);
    bool isOperator(string ifOperator);
};
*/

#endif //PROJECT_CONDITIONPARSER_H
