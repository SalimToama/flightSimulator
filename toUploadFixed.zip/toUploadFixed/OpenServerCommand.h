
#ifndef PROJECT_OPENSERVERCOMMAND_H
#define PROJECT_OPENSERVERCOMMAND_H

#include "Command.h"
#include "dataBase.h"

//#include <thread>
class OpenServerCommand: public Command {
    vector<string>::iterator &iterator1;
    dataBase *allMaps;
public:

    OpenServerCommand(
            vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1,
            dataBase *allMaps);

    int doCommand(vector<string> text,int i);
};



#endif //PROJECT_OPENSERVERCOMMAND_H
