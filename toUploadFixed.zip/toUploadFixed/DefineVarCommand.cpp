//
// Created by issa on 12/10/18.
//

#include "DefineVarCommand.h"
/*
DefineVarCommand::DefineVarCommand(map<string, double> &symbolTable, map<string, string> &bindingTable,
                                   vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1)
        : symbolTable(symbolTable), bindingTable(bindingTable), iterator1(iterator1) {}
*/


int DefineVarCommand::doCommand(vector<string> text,int index) {
    if(*iterator1 == "var"){
        string var = *++iterator1;
        this->allTheMaps->setSymbolTable(*iterator1,0);
        while (*iterator1 != "bind"){
            ++iterator1;
        }
        this->allTheMaps->setBindingMap(var,*++iterator1);
        *++iterator1;
    }
    return 0;
}

DefineVarCommand::DefineVarCommand(
        vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1,
        dataBase *allTheMaps) : iterator1(iterator1), allTheMaps(allTheMaps) {}
