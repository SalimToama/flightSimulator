//
// Created by issa on 12/12/18.
//

#ifndef PROJECT_PARSER_H
#define PROJECT_PARSER_H

#include <iostream>
#include <map>
#include <vector>
#include "Expression.h"
#include "whileCommand.h"
#include "ifCommand.h"
#include "DefineVarCommand.h"
#include "printCommand.h"
#include "CommandExpression.h"
#include "OpenServerCommand.h"
#include "ConnectCommand.h"
#include "dataBase.h"
#include <bits/stdc++.h>
enum commandType{SERVER,CONNECT,VAR,IF,PRINT,WHILE};
using namespace std;
class Parser {
private:
    vector<string> toInterpret;
    vector<string>::iterator it;
    dataBase *allTheMaps;
    int index;
public:
    Parser(const vector<string> &text);
    void split();
    void createCommand();
    void updateSymbolTable();
    /*
    void initializeSymbolTable(string var);
    commandType getRightEnum(string command);
     */
};


#endif //PROJECT_PARSER_H
