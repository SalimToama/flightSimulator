//
// Created by issa on 12/16/18.
//

#ifndef PROJECT_DATABASE_H
#define PROJECT_DATABASE_H

#include <string>
#include <map>
#include <vector>
#include "Expression.h"

using namespace std;

class dataBase {
    map<string, Expression *> commandTable;
    map<string, string> bindingMap;
    map<string, double> symbolTable;
public:

    dataBase();

    const map<string, Expression *> &getCommandTable() const;

    void setCommandTable(const string &string1, Expression* expression);

    const map<string, string> &getBindingMap() const;

    void setBindingMap(const string &key,const string &value);

    const map<string, double> &getSymbolTable() const;

    void setSymbolTable(const string &keySymbol,const double &value);
};


#endif //PROJECT_DATABASE_H
