//
// Created by issa on 12/12/18.
//

#include "ifCommand.h"
/*
ifCommand::ifCommand(
        vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1)
        : iterator1(iterator1) {}

int ifCommand::doCommand(vector<string> text,int index){
    /*
    conditionParser parser(iterator1);
    if(parser.doCommand(text,index)){
        return 0;
    }else{
        while (*iterator1 != "}"){
            *iterator1++;
        }
    }
     */
/*
    *iterator1++;
    return 0;
}
*/