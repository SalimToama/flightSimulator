//
// Created by issa on 12/16/18.
//

#include "setCommand.h"

setCommand::setCommand(
        vector<std::__cxx11::basic_string<char, std::char_traits<char>,
                std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>,
                        std::allocator<char>>>>::iterator &iterator1)
        : iterator1(iterator1) {}

int setCommand::doCommand(vector<string> text, int index) {

}
