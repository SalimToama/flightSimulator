//
// Created by issa on 12/15/18.
//

#include "conditionParser.h"
/*
conditionParser::conditionParser(
        vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iteratorOverFile)
        : iteratorOverFile(iteratorOverFile) {}

int conditionParser::doCommand(vector<string> operation, int index) {
    string leftExpression;
    string rightExpression;
    while(!isOperator(*iteratorOverFile)){
        leftExpression += *iteratorOverFile++;
    }
    string operatorByString = *iteratorOverFile++;
    while (*iteratorOverFile !=")"){
        rightExpression += *++iteratorOverFile;
    }
    if(operatorByString == ">"){
        return atoi(leftExpression.c_str()) > atoi(rightExpression.c_str());
    }
    if(operatorByString == "<"){
        return atoi(leftExpression.c_str()) < atoi(rightExpression.c_str());
    }
    if(operatorByString == ">="){
        return atoi(leftExpression.c_str()) >= atoi(rightExpression.c_str());
    }
    if(operatorByString == "<="){
        return atoi(leftExpression.c_str()) <= atoi(rightExpression.c_str());
    }
    if(operatorByString == "=="){
        return atoi(leftExpression.c_str()) == atoi(rightExpression.c_str());
    }
    if(operatorByString == "!="){
        return atoi(leftExpression.c_str()) != atoi(rightExpression.c_str());
    }
    return 0;
}

bool conditionParser::isOperator(string ifOperator) {
    return (ifOperator == ">" || ifOperator == "<" || ifOperator == ">=" || ifOperator == "<="
           || ifOperator == "!=" || ifOperator == "==");
}
*/