//
// Created by issa on 12/12/18.
//

#ifndef PROJECT_IFCOMMAND_H
#define PROJECT_IFCOMMAND_H

#include <iostream>
#include <vector>
#include "conditionParser.h"
/*
class ifCommand : public conditionParser{
    vector<string>::iterator &iterator1;
public:

    ifCommand(
            vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1);

    int doCommand(vector<string> text,int index);
};
*/

#endif //PROJECT_IFCOMMAND_H
