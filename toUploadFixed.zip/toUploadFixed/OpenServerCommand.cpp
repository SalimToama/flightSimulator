//
// Created by issa on 12/10/18.

#include "OpenServerCommand.h"
#include "DataReaderServer.h"
using namespace std;

OpenServerCommand::OpenServerCommand(
        vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1,
        dataBase *allMaps) : iterator1(iterator1), allMaps(allMaps) {}

int OpenServerCommand::doCommand(vector<string> text, int index) {
    int port = 0, hertz = 0;
    port = atoi((*++iterator1).c_str());
    hertz = atoi((*++iterator1).c_str()); //TODO make function in DataReaderServer ( call it openServer and give the parameter).
    ++iterator1;
    thread threadServer(DataReaderServer(),port,hertz,allMaps);
    threadServer.detach();
    return 0;
}
