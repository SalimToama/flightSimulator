#include <regex>
#include "Parser.h"

#define command 0

Parser::Parser(const vector<string> &text) {
    this->toInterpret = text;
    this->it = this->toInterpret.begin();
}

void Parser::createCommand() {
    this->allTheMaps = new dataBase();
    this->allTheMaps->setCommandTable("openDataServer",
                                      new CommandExpression(toInterpret, new OpenServerCommand(it, allTheMaps)));
    this->allTheMaps->setCommandTable("connect",
                                      new CommandExpression(toInterpret, new ConnectCommand(it, allTheMaps)));
    //this->allTheMaps->setCommandTable("var",new CommandExpression(toInterpret,new DefineVarCommand(it,allTheMaps)));
    //this->allTheMaps->setCommandTable("print",new CommandExpression(toInterpret,new printCommand(allTheMaps->getSymbolTable(),it)));
    //this->allTheMaps->setCommandTable("print", new CommandExpression(toInterpret,new printCommand(allTheMaps->getSymbolTable(),it)));
    //this->allTheMaps->setCommandTable("if", new CommandExpression(toInterpret,new ifCommand(it)));
    split();
}

void Parser::split() {
    int i = 0;
    int j = 0;
    /*
    ++it;
    ++it;
    ++it;
    ++it;
    ++it;
    ++it;
     */
    while (it != this->toInterpret.end()) {
        Expression *expression = this->allTheMaps->getCommandTable().find(*it)->second;
        if (expression != nullptr) {
            expression->calculate();
        }
        j++;
        if (j == 2) {
            while (true) {
                if (i % 1000000000 == 0) {
                    cout << i << endl;
                }
                i++;
            }
        }
    }
}

void Parser::updateSymbolTable() {
    string var = *it++;
    //symbolTable[var] = atoi((*++it).c_str());
    *it++;
}
/*
for (int i = 0; i < toInterpret.size(); i++) {

}
 */
