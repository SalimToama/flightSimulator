//
// Created by issa on 12/12/18.
//

#include "whileCommand.h"

int whileCommand::doCommand(string line) {
    return 0;
}
/*
whileCommand::whileCommand() {

}
*/