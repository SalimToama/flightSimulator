#ifndef PROJECT_DEFINEVARCOMAND_H
#define PROJECT_DEFINEVARCOMAND_H

#include "Command.h"

class DefineVarComand :public Command{
    //DefineVarComand();
    int doCommand(string operation);
};


#endif //PROJECT_DEFINEVARCOMAND_H
