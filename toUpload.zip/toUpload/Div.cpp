//
// Created by issa on 12/10/18.
//

#include "Div.h"
Div::Div(Expression *left, Expression *right) : BinaryExpression(left, right) {}

double Div::calculate() {

}
