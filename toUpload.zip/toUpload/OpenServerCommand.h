
#ifndef PROJECT_OPENSERVERCOMMAND_H
#define PROJECT_OPENSERVERCOMMAND_H

#include <vector>
#include "Command.h"

class OpenServerCommand: public Command {
    int doCommand(string operation);
    vector<string> split(string line);
};


#endif //PROJECT_OPENSERVERCOMMAND_H
