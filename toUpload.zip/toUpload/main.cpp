#include <iostream>
#include <fstream>
#include <vector>
#include "Parser.h"
#include "ShuntingYard.h"
#define INSTRUCTIONS "intersection"
using namespace std;

vector<string> lexer(const string &text) {
    vector<string> lines;
    ifstream file;
    string lineFromText;
    if (!file.is_open()) {
        file.open(text, fstream::app | fstream::out);
    }
    while (getline(file, lineFromText)) {
        lines.push_back(lineFromText);
    }
    file.close();
    return lines;
}

int main() {
    vector<string> linesFromText = lexer(INSTRUCTIONS);
    auto *parser = new Parser(linesFromText);
    parser->split();
    /*
    ShuntingYard e;
    cout << e.evaluate("10 + 2 * 3");
     */
}