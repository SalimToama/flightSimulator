//
// Created by issa on 12/12/18.
//

#ifndef PROJECT_PRINTCOMMAND_H
#define PROJECT_PRINTCOMMAND_H

#include "Command.h"

class printCommand :public Command{
public:
    printCommand();
    int doCommand(string operation);
};


#endif //PROJECT_PRINTCOMMAND_H
