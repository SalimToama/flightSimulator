#ifndef PROJECT_BINARYEXPRESSION_H
#define PROJECT_BINARYEXPRESSION_H

#include "Expression.h"

class BinaryExpression : public Expression{
protected:
    Expression *left;
    Expression *right;
public:
    BinaryExpression(Expression *left, Expression *right)
    {
        this->left = left;
        this->right = right;
    }
    double calculate();
};

double BinaryExpression::calculate() {
    return 0;
}


#endif //PROJECT_BINARYEXPRESSION_H
