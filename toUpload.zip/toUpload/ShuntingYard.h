//
// Created by issa on 12/13/18.
//

#ifndef PROJECT_SHUNTINGYARD_H
#define PROJECT_SHUNTINGYARD_H
#include <bits/stdc++.h>
using namespace std;
class ShuntingYard {
public:
    int precedence(char op);
    int applyOp(int a, int b, char op);
    int evaluate(string tokens);
};


#endif //PROJECT_SHUNTINGYARD_H
