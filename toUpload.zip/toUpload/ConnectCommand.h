#ifndef PROJECT_CONNECTCOMAND_H
#define PROJECT_CONNECTCOMAND_H

#include "Command.h"
#include <vector>
#include <regex>
class ConnectCommand :public Command{
public:
    ConnectCommand();
    vector<string> split(const string &line);
    int doCommand(string operation);
};


#endif //PROJECT_CONNECTCOMAND_H
