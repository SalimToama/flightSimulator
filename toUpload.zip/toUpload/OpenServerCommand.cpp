//
// Created by issa on 12/10/18.
//

#include <regex>
#include "OpenServerCommand.h"

int OpenServerCommand::doCommand(string operation) {
    vector<string> afterSplit = split(operation);
    if(afterSplit.size() != 2){
        cout << "require information not available";
        exit(0);
    }
    return 2;
}

vector<string> OpenServerCommand::split(string line) {
    stringstream lineFromText(line);
    istream_iterator <string> begin(lineFromText);
    istream_iterator <string> end;
    vector<string> complete(begin, end);
    return complete;
}
