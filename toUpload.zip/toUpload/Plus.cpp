//
// Created by issa on 12/10/18.
//

#include "Plus.h"

Plus::Plus(Expression *left, Expression *right) : BinaryExpression(left, right) {

}

double Plus::calculate() {

}
