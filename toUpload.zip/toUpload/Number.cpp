//
// Created by issa on 12/10/18.
//

#include "Number.h"

Number::Number(double value) {
    this->value = value;
}

double Number::calculate() {
    return value;
}
