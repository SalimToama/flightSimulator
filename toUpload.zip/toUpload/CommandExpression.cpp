//
// Created by issa on 12/10/18.
//

#include "CommandExpression.h"

CommandExpression::CommandExpression(Command *command) {}

double CommandExpression::calculate() {
    string line;
    return this->command->doCommand(line);
}

