//
// Created by issa on 12/12/18.
//
#include <regex>
#include "Parser.h"
#define command 0
#define var 1
#define equal 1
#define value 2

Parser::Parser(const vector<string> &text) {
    this->toInterpeter = text;
}

void Parser::split() {
    for (int i = 0; i < toInterpeter.size(); i++) {
        //function to split the line by spaces.
        stringstream lineFromText(toInterpeter[i]);
        istream_iterator <string> begin(lineFromText);
        istream_iterator <string> end;
        vector<string> complete(begin, end);
        if(complete[command] == "var") initializeSymbolTable(complete[var]);
        if(complete[equal] == "=") updateSymbolTable(complete[command],complete[value]);
        createCommand(getRightEnum(complete[command]));
    }
}

void Parser::createCommand(commandType theCommand) {
    switch (theCommand) {
        case SERVER:
            this->commandTable["openDataServer"] = new CommandExpression(new OpenServerCommand());
            break;
        case CONNECT:
            this->commandTable["connect"] = new CommandExpression(new ConnectCommand());
            break;
        case WHILE:
            this->commandTable["while"] = new CommandExpression(new whileCommand());
            break;
        case IF:
            this->commandTable["if"] = new CommandExpression(new ifCommand());
            break;
        case PRINT:
            this->commandTable["print"] = new CommandExpression(new printCommand());
            break;
        case VAR:
            this->commandTable["var"] = new CommandExpression(new DefineVarComand());
        default:
            cout << "Not Available command";
            exit(0);
    }
}

commandType Parser::getRightEnum(string theCommand) {
    if(theCommand == "openDataServer") return SERVER;
    if(theCommand == "while") return WHILE;
    if(theCommand == "print") return PRINT;
    if(theCommand == "connect")return CONNECT;
    if(theCommand == "var") return VAR;
    if(theCommand == "if") return IF;
    cout << "Not Available command";
    exit(0);
}

void Parser::initializeSymbolTable(string varAsString) {
    this->symbolTable[varAsString] = 0;
}

void Parser::updateSymbolTable(string varSsString,string valueAsString){
    symbolTable[varSsString] = atoi(valueAsString.c_str());
}


