#ifndef PROJECT_COMMAND_H
#define PROJECT_COMMAND_H

#include <iostream>
//#include <string.h>
using namespace std;
/*
 * interface for the interpreter.
 */
class Command {
public:
    // execute the specific command.
    virtual int doCommand(string operation) = 0;
};

#endif //PROJECT_COMMAND_H
