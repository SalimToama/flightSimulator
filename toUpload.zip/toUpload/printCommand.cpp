//
// Created by issa on 12/12/18.
//

#include "printCommand.h"

printCommand::printCommand() {

}

int printCommand::doCommand(string operation) {
    return 0;
}
