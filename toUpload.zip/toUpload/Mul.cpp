//
// Created by issa on 12/10/18.
//

#include "Mul.h"

Mul::Mul(Expression *left, Expression *right) : BinaryExpression(left, right) {

}

double Mul::calculate() {

}
