//
// Created by issa on 12/10/18.
//

#include "DefineVarComand.h"

int DefineVarComand::doCommand(string operation) {

}