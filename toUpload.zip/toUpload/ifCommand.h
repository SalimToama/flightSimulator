//
// Created by issa on 12/12/18.
//

#ifndef PROJECT_IFCOMMAND_H
#define PROJECT_IFCOMMAND_H


#include "Command.h"

class ifCommand : public Command{
public:
    //ifCommand();
    int doCommand(string line);
};


#endif //PROJECT_IFCOMMAND_H
