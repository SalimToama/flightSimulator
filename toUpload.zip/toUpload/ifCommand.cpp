//
// Created by issa on 12/12/18.
//

#include "ifCommand.h"

int ifCommand::doCommand(string line) {
    return 0;
}
/*
ifCommand::ifCommand() {

}
*/