#ifndef PROJECT_WHILECOMMAND_H
#define PROJECT_WHILECOMMAND_H


#include "Command.h"

class whileCommand : public Command{
public:
    //whileCommand();
    int doCommand(string line);

};


#endif //PROJECT_WHILECOMMAND_H
