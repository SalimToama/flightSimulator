//
// Created by issa on 12/12/18.
//

#ifndef PROJECT_PARSER_H
#define PROJECT_PARSER_H

#include <iostream>
#include <map>
#include <vector>
#include "Expression.h"
#include "whileCommand.h"
#include "ifCommand.h"
#include "DefineVarComand.h"
#include "printCommand.h"
#include "CommandExpression.h"
#include "OpenServerCommand.h"
#include "ConnectCommand.h"
enum commandType{SERVER,CONNECT,VAR,IF,PRINT,WHILE};
using namespace std;
class Parser {
private:
    vector<string> toInterpeter;
    map<string,Expression*> commandTable;
    map<string,double > symbolTable;
public:
    Parser(const vector<string> &text);
    void split();
    void initializeSymbolTable(string var);
    void updateSymbolTable(string var,string value);
    commandType getRightEnum(string command);
    void createCommand(commandType theCommand);
};


#endif //PROJECT_PARSER_H
