#include "ConnectCommand.h"

int ConnectCommand::doCommand(string operation) {
    vector<string> afterSplit = split(operation);
    if(afterSplit.size() != 2){
        cout << "require information not available";
        exit(0);
    }
    return 2;
}
vector<string> ConnectCommand::split(const string &line) {
    stringstream lineFromText(line);
    istream_iterator <string> begin(lineFromText);
    istream_iterator <string> end;
    vector<string> complete(begin, end);
    return complete;
}
ConnectCommand::ConnectCommand(){

}

