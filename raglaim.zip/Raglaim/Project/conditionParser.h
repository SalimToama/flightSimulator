
#ifndef PROJECT_CONDITIONPARSER_H
#define PROJECT_CONDITIONPARSER_H


#include <list>
#include "Command.h"
#include "Expression.h"

class conditionParser : public Command{
    vector<string>::iterator &iter;
    list<Expression*> expression;
public:

    conditionParser(vector<string>::iterator &iter);
    void saveCommand(vector<string> &it);
    int doCommand(vector<string> &operation,int index);
    bool isOperator(string ifOperator);
};


#endif //PROJECT_CONDITIONPARSER_H
