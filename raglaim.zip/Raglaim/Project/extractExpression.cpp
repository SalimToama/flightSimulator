//
// Created by issa on 12/18/18.
//

#include "extractExpression.h"

vector<string> extractExpression::extract(vector<string>::iterator &it, vector<string> &vec) {
    int counter = 1;
    *it++;
    vector<string> ls;
    ostringstream ss;
    //vector<string>::iterator it = vec.begin();
    int brac = 0;
    while (it != vec.end()) {
        if (isCommand(*it))
            break;
        // Numbers.
        if (ShuntingYard::isNumber(it->at(0))) {
            if (counter != 0) {
                ss << " " << *it;
                if (brac == 0)
                    counter--;
                it++;
                continue;
            }
            ls.push_back(ss.str());
            ss.str(string());
            ss << " " << *it;
            it++;
            continue;
        }
        // Brackets.
        if (ShuntingYard::isRightParen(it->at(0))) {
            brac--;
            if (brac == 0) {
                counter--;
            }
            ss << " " << *it;
            it++;
            continue;
        }
        if (ShuntingYard::isLeftParen(it->at(0))) {
            brac++;
            ss << " " << *it;
            it++;
            continue;
        }
        // Operators.
        if (ShuntingYard::isOperator(it->at(0))) {
            if (!brac)
                counter++;
            ss << " " << *it;
            it++;
            continue;
        }
            // Vars.
        else {
            if (counter) {
                ss << " " << *it;
                if (!brac)
                    counter--;
                it++;
                continue;
            } else {
                ls.push_back(ss.str());
                ss.str(string());
                ss << " " << *it;
                it++;
                continue;
            }
        }
    }
    ls.push_back(ss.str());
    for (auto &l : ls)
        l.erase(0, 1);
    return ls;
}

bool extractExpression::isCommand(string str) {
    if (str == "connect" || str == "var" || str == "openDataServer" || str == "print" || str == "sleep" || str == "while"
            || str == "if") {
        return true;
    }
}
