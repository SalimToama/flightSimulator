//
// Created by issa on 12/16/18.
//

#ifndef PROJECT_SLEEP_H
#define PROJECT_SLEEP_H


#include "Command.h"
#include <unistd.h>
class Sleep : public Command{
    vector<string>::iterator &iterator1;
public:
    int doCommand(vector<string> text,int index);
};


#endif //PROJECT_SLEEP_H
