//
// Created by issa on 12/16/18.
//

#include "dataBase.h"
#include "CommandExpression.h"
#include "DefineVarCommand.h"

dataBase::dataBase() = default;

const map<string, Expression *> &dataBase::getCommandTable() const {
    return commandTable;
}

void dataBase::setCommandTable(const string &commandTable,Expression* expression) {
    this->commandTable[commandTable] = expression;
}

const map<string, string> &dataBase::getBindingMap() const {
    return bindingMap;
}

void dataBase::setBindingMap(const string &key,const string &value) {
    this->bindingMap[key] = value;
}

const map<string, double> &dataBase::getSymbolTable() const {
    return symbolTable;
}

void dataBase::setSymbolTable(const string &keySymbol,const double &value) {
    this->symbolTable[keySymbol] = value;
}
