#ifndef PROJECT_DEFINEVARCOMAND_H
#define PROJECT_DEFINEVARCOMAND_H

#include "Command.h"
#include "dataBase.h"
#include <map>
using namespace std;
class DefineVarCommand :public Command{
    //map<string,double> &symbolTable;
    //map<string,string> &bindingTable;
    vector<string>::iterator &iterator1;
    dataBase* allTheMaps;
public:

    DefineVarCommand(
            vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1,
            dataBase *allTheMaps);

    int doCommand(vector<string> text,int index);
};


#endif //PROJECT_DEFINEVARCOMAND_H
