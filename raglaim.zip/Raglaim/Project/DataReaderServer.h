//
// Created by issa on 12/14/18.
//

#ifndef PROJECT_DATAREADERSERVER_H
#define PROJECT_DATAREADERSERVER_H

#include <iostream>
#include <sys/socket.h>
#include "dataBase.h"

using namespace std;
class DataReaderServer {
public:
    void operator()(int port, int hertz, dataBase *allMaps);
};


#endif //PROJECT_DATAREADERSERVER_H
