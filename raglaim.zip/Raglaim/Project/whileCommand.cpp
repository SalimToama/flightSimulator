//
// Created by issa on 12/12/18.
//

#include "whileCommand.h"
/*
whileCommand::whileCommand(
        vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1)
        : iterator1(iterator1) {}

int whileCommand::doCommand(vector<string> text,int index) {
    //conditionParser parser(iterator1);
    //while (parser.doCommand(text,index)){

    //}
    while (*iterator1 != "}"){
        *iterator1++;
    }
    *iterator1++;
    return 0;
}
 */
/*
 *   return 0;
    }else{

 */