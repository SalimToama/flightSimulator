//
// Created by issa on 12/17/18.
//

#ifndef PROJECT_LEXER_H
#define PROJECT_LEXER_H
using namespace std;
#include <iostream>
#include <string>
#include <vector>
#include <fstream>

class lexer {
public:
    vector<string> lexerToTextFile(const string &lexer);
    vector<string> splitLine(const string& line);
    vector<string> manageStrings(const vector<string> &afterSpacer);
    void spacer(string &after);
    bool ifNumber(char number);
    bool isLeftParentheses(char parentheses);
    bool isRightParentheses(char parnthese);
    bool isOperator(char operation);
};


#endif //PROJECT_LEXER_H
