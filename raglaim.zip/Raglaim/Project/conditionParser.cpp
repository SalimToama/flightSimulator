//
// Created by issa on 12/15/18.
//

#include "conditionParser.h"

conditionParser::conditionParser(vector<string>::iterator &iter) : iter(iter) {}

int conditionParser::doCommand(vector<string> &operation, int index) {
    string leftExpression;
    string rightExpression;
    while(!isOperator(*iter)){
        leftExpression += *iter++;
    }
    string operatorByString = *iter++;
    while (*iter !="{"){
        rightExpression += *++iter;
    }
    if(operatorByString == ">"){
        return atoi(leftExpression.c_str()) > atoi(rightExpression.c_str());
    }
    if(operatorByString == "<"){
        return atoi(leftExpression.c_str()) < atoi(rightExpression.c_str());
    }
    if(operatorByString == ">="){
        return atoi(leftExpression.c_str()) >= atoi(rightExpression.c_str());
    }
    if(operatorByString == "<="){
        return atoi(leftExpression.c_str()) <= atoi(rightExpression.c_str());
    }
    if(operatorByString == "=="){
        return atoi(leftExpression.c_str()) == atoi(rightExpression.c_str());
    }
    if(operatorByString == "!="){
        return atoi(leftExpression.c_str()) != atoi(rightExpression.c_str());
    }
    return 0;
}

bool conditionParser::isOperator(string ifOperator) {
    return (ifOperator == ">" || ifOperator == "<" || ifOperator == ">=" || ifOperator == "<="
           || ifOperator == "!=" || ifOperator == "==");
}

void conditionParser::saveCommand(vector <string> &it) {

}
