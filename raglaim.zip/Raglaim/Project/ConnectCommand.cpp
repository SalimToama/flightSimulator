#include "ConnectCommand.h"
#include "ClientServer.h"
#include "DataReaderServer.h"

int ConnectCommand::doCommand(vector<string> text, int index) {
    string ip = "";
    int port = 0;
    ip = *++iterator1;
    port = atoi((*++iterator1).c_str()); //TODO make function in DataReaderServer ( call it openServer and give the parameter).
    thread threadClient(ClientServer(),ip,port,allMaps);
    threadClient.detach();
}

ConnectCommand::ConnectCommand(vector<string>::iterator &iterator1, dataBase *allMaps) : iterator1(iterator1), allMaps(allMaps) {}
