//
// Created by issa on 12/12/18.
//

#include "printCommand.h"
#include "SymbolTable.h"

printCommand::printCommand(vector<string>::iterator &iterator1) : iterator1(iterator1) {}

void printCommand::doCommand(vector<string> &text) {
    string output = *++iterator1;
    if (SymbolTable::instance()->atTable(output)) {
        cout << output + " " << SymbolTable::instance()->getValue(output) << "\n";
    } else {
        cout << output << endl;
    }
    ++iterator1;
}
