#include "CommandExpression.h"

CommandExpression::CommandExpression(vector<string> &linesFromText, Command *command) : linesFromText(
        linesFromText), command(command) {}

double CommandExpression::calculate() {
    this->command->doCommand(linesFromText);
    return 1;
}




