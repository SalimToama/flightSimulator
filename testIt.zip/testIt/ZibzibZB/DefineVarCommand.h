
#ifndef PROJECT_DEFINEVARCOMAND_H
#define PROJECT_DEFINEVARCOMAND_H

#include "Command.h"
#include "extractExpression.h"
#include "BIndingTable.h"
#include <map>
using namespace std;
class DefineVarCommand :public Command{
    vector<string>::iterator &iterator1;
public:
    DefineVarCommand(vector<string>::iterator &iterator1);
    void doCommand(vector<string> &text);
};


#endif //PROJECT_DEFINEVARCOMAND_H