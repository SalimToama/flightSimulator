//
// Created by issa on 12/23/18.
//

#ifndef PROJECT_COMMANDENTERC_H
#define PROJECT_COMMANDENTERC_H


#include "Command.h"

class CommandenterC : public Command {
    vector<string>::iterator &iterator1;
public:
    CommandenterC(
            vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1);

    void doCommand(vector<string> &text);
};


#endif //PROJECT_COMMANDENTERC_H
