//
// Created by issa on 12/10/18.
//

#include "Number.h"
#include "expressionList.h"

Number::Number(double number) {
    this->valueNumber = number;
    expressionList::instance()->setValue(this);
}

double Number::calculate() {
    return valueNumber;
}
