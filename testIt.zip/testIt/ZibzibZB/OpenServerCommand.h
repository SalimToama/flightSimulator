#ifndef PROJECT_OPENSERVERCOMMAND_H
#define PROJECT_OPENSERVERCOMMAND_H

#include "Command.h"
#include "dataCommand.h"
#include "extractExpression.h"
#include "DataReaderServer.h"

//#include <thread>
class OpenServerCommand: public Command {
    vector<string>::iterator &iterator1;
public:

    OpenServerCommand(vector<string>::iterator &iter);

    void doCommand(vector<string> &text);
};



#endif //PROJECT_OPENSERVERCOMMAND_H
