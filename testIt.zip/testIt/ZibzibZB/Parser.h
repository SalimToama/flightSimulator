//
// Created by issa on 12/12/18.
//
#ifndef PROJECT_PARSER_H
#define PROJECT_PARSER_H

#include <iostream>
#include <map>
#include <vector>
#include "Expression.h"
#include "whileCommand.h"
#include "ifCommand.h"
#include "DefineVarCommand.h"
#include "printCommand.h"
#include "CommandExpression.h"
#include "OpenServerCommand.h"
#include <regex>
#include "dataCommand.h"
#include "extractExpression.h"
#include "ConnectCommand.h"
#include "Sleep.h"
#include <bits/stdc++.h>
using namespace std;
class Parser {
private:
    map<string, Expression*> expressionMap;
    map<string, Command*> commandMap;
    vector<string> &toInterpret;
    vector<string>::iterator it;
    int index;
public:
    Parser(vector<string> &text);
    void split();
    ~Parser();
    vector<string> splitLine(const string &line);
    void createCommand();
    void updateSymbolTable();
    bool symbolExists(string st);
    /*
    void initializeSymbolTable(string var);
    commandType getRightEnum(string command);
     */
};


#endif //PROJECT_PARSER_H