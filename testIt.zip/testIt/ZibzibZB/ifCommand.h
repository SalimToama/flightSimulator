//
// Created by issa on 12/12/18.
//
#ifndef PROJECT_IFCOMMAND_H
#define PROJECT_IFCOMMAND_H

#include <iostream>
#include <vector>
#include "conditionParser.h"
#include "Parser.h"
class ifCommand : public conditionParser {
    vector<string>::iterator &iterator1;
public:
    ifCommand(vector<string>::iterator &iter);

    void doCommand(vector<string> &text);
};

#endif //PROJECT_IFCOMMAND_H
