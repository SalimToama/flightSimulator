//
// Created by issa on 12/16/18.
//
#ifndef PROJECT_SETCOMMAND_H
#define PROJECT_SETCOMMAND_H

#include <iostream>
#include <sstream>
#include <stack>
#include <cstdlib>
#include "Command.h"

class setCommand : public Command {
    vector<string>::iterator &iterator1;
public:
    setCommand(
            vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1);

    int doCommand(vector<string> &text,int index);
};


#endif //PROJECT_SETCOMMAND_H
