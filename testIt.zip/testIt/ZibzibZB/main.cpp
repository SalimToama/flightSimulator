#include <iostream>
#include <fstream>
#include <vector>
#include "Parser.h"
#include "ShuntingYard.h"
#include "lexer.h"
#include "dictionaryPath.h"
#include "SymbolTable.h"
#include "BIndingTable.h"
#include "ClientServer.h"
#include "expressionList.h"

#define INSTRUCTIONS "test"
using namespace std;
dictionaryPath *dictionaryPath::map_instance = NULL;
SymbolTable *SymbolTable::map_instance = NULL;
BIndingTable *BIndingTable::map_instance = NULL;
expressionList *expressionList::map_instance = NULL;

int main() {
    lexer lexer1;
    vector<string> sender = lexer1.lexerToTextFile(INSTRUCTIONS);
    Parser parser(sender);
    parser.createCommand();
    exit(0);
}