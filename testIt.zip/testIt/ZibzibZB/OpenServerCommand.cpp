//
// Created by issa on 12/10/18.
#include "OpenServerCommand.h"


using namespace std;

OpenServerCommand::OpenServerCommand(vector<string>::iterator &iter) : iterator1(iter) {}

void OpenServerCommand::doCommand(vector<string> &text) {
    double port = 0, hertz = 0;
    iterator1++;
    port = extractExpression::extract(iterator1, text)->calculate();
    hertz = extractExpression::extract(iterator1, text)->calculate();
    //*++iterator1;
    thread threadServer(DataReaderServer(),port,hertz);
    threadServer.detach();
}
