#pragma once

#ifndef PROJECT_DEFINEVARCOMAND_H
#define PROJECT_DEFINEVARCOMAND_H

#include "Command.h"
#include "dataBase.h"
#include "extractExpression.h"
#include "BIndingTable.h"
#include <map>
using namespace std;
class DefineVarCommand :public Command{
    //map<string,double> &symbolTable;
    //map<string,string> &bindingTable;
    vector<string>::iterator &iterator1;
public:
    DefineVarCommand(vector<string>::iterator &iterator1);
    int doCommand(vector<string> &text,int index);
};


#endif //PROJECT_DEFINEVARCOMAND_H