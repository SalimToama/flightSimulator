//
// Created by issa on 12/10/18.
//

#include "DefineVarCommand.h"


int DefineVarCommand::doCommand(vector<string> &text, int index) {
    if (*iterator1 == "var") { // if stands on 'var'
        iterator1++;
        //this->allTheMaps->setSymbolTable(*iterator1, 0);
        SymbolTable::instance()->setValue(*iterator1, 0);
    }
    string var = *iterator1; // stands on var name.
    iterator1++; // Now either stands on '=' or on the next command.
    if (*iterator1 == "=") {
        if (*++iterator1 == "bind") {
            // IN SEPARATE function.
            string path = *++iterator1; // Now stands on path.
            // if it's a path and not a var.
            if (!SymbolTable::instance()->atTable(path)){
            //double s = SymbolTable::instance()->getValue(path);
                BIndingTable::instance()->setValue(var, path);
            }
            else{
                BIndingTable::instance()->setValue(var, (BIndingTable::instance()->getValue(path)));
            }

            iterator1++; // Now stands on the next command.
            return 0;

        }
        //this->allTheMaps->setSymbolTable(var, extractExpression::extract(iterator1, text)->calculate());
        SymbolTable::instance()->setValue(var, extractExpression::extract(iterator1, text)->calculate());
    }
    return 0;
    // Currently irrelevant.
    /*
    while (*iterator1 != "bind") {
        ++iterator1;
    }
    this->allTheMaps->setBindingMap(var, *++iterator1);
     */
    return 0;
}

DefineVarCommand::DefineVarCommand(vector<string>::iterator &iterator1) : iterator1(iterator1) {}