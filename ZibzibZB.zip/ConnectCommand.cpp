#include "ConnectCommand.h"
#include "ClientServer.h"
#include "DataReaderServer.h"
#include "extractExpression.h"
#include "CommandExpression.h"
#include "DefineVarCommand.h"

int ConnectCommand::doCommand(vector<string> &text, int index) {
    // Currently stands on connect.
    string ip = "";
    double port = 0;
    ip = *(++iterator1); // stands on ip address
    iterator1++;
    // Now stands on the port expression part.
    port =  extractExpression::extract(this->iterator1, text)->calculate();
    thread threadClient(ClientServer(),ip,port);
    threadClient.detach();
}

ConnectCommand::ConnectCommand(vector<string>::iterator &iterator1) : iterator1(iterator1){}