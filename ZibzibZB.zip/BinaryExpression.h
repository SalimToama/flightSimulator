#pragma once

#ifndef PROJECT_BINARYEXPRESSION_H
#define PROJECT_BINARYEXPRESSION_H

#include "Expression.h"

class BinaryExpression : public Expression{
protected:
    Expression *left;
    Expression *right;
public:
    BinaryExpression(Expression *left, Expression *right) : left(left), right(right) {}
};

#endif //PROJECT_BINARYEXPRESSION_H
