//
// Created by issa on 12/12/18.
//

#include "printCommand.h"

printCommand::printCommand(
                           vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1)
        :  iterator1(iterator1) {}
int printCommand::doCommand(vector<string> &text,int index) {
    //cout << symbolTable[*iterator1] << "\n";
    return 0;
}
