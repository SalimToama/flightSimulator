#include "Parser.h"

#define command 0

Parser::Parser(vector<string> &text) : toInterpret(text) {
    this->it = this->toInterpret.begin();
}

void Parser::createCommand() {
    this->expressionMap["openDataServer"] = new CommandExpression(toInterpret, new OpenServerCommand(it));
    this->expressionMap["var"] = new CommandExpression(toInterpret, new DefineVarCommand(it));
    this->expressionMap["while"] = new CommandExpression(toInterpret, new whileCommand(it));
    this->expressionMap["if"] = new CommandExpression(toInterpret, new ifCommand(it));
    this->expressionMap["print"] = new CommandExpression(toInterpret, new printCommand(it));
    //this->expressionMap["sleep"] = new CommandExpression(toInterpret,new sleepCommand(it));
    split();
}

void Parser::split() {
    int i = 0;
    int j = 0;
    /*
    ++it;
    ++it;
    ++it;
    ++it;
    ++it;
    ++it;
     */
    while (it != this->toInterpret.end()) {
        Expression *expression;
        // if symbol instead of command var, assign the define command.
        if (symbolExists(*it))
            expression = this->expressionMap.find("var")->second;
        else
            expression = this->expressionMap.find(*it)->second;
        if (expression != nullptr) {
            expression->calculate();
        }
        j++;
        /*
        if (j == 1) {
            while (true) {
                if (i % 1000000000 == 0) {
                }
                i++;
            }
        }
         */
    }
}

bool Parser::symbolExists(string var) {
    for (auto iter = SymbolTable::instance()->getBegin(); iter != SymbolTable::instance()->getEnd(); iter++) {
        if (SymbolTable::instance()->atTable(var)) {
            return true;
        }
    }
    return false;
}
