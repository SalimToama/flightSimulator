//
// Created by issa on 12/10/18.
//

#include "Number.h"

Number::Number(double number) {
    this->valueNumber = number;
}

double Number::calculate() {
    return valueNumber;
}
