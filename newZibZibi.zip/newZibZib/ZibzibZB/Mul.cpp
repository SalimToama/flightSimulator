//
// Created by issa on 12/10/18.
//

#include "Mul.h"

Mul::Mul(Expression *left, Expression *right) : BinaryExpression(left, right) {
    expressionList::instance()->setValue(this);
}

double Mul::calculate() {
    return this->left->calculate() * this->right->calculate();
}

Mul::~Mul() {
    if (left != nullptr) {
        delete left;
    }
    if (right != nullptr) {
        delete right;
    }
}
