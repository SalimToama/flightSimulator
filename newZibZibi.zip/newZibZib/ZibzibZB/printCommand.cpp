//
// Created by issa on 12/12/18.
//

#include "printCommand.h"
#include "SymbolTable.h"

printCommand::printCommand(vector<string>::iterator &iterator1) :  iterator1(iterator1) {}
int printCommand::doCommand(vector<string> &text,int index) {
    string output = *++iterator1;
    if(SymbolTable::instance()->atTable(output)){
        cout << SymbolTable::instance()->getValue(output);
    }else {
        cout << output << endl;
    }
    return 0;
}
