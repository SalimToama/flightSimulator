#pragma once
#ifndef PROJECT_COMMANDTABLE_H
#define PROJECT_COMMANDTABLE_H

using namespace std;
#include <map>

#include <string>
#include "Expression.h"
class commandTable {
    map<string, Expression*> pathMap;
    static commandTable *map_instance;
public:
    static inline commandTable *instance() {
        if (map_instance == nullptr) {
            map_instance = new commandTable();
        }
        return map_instance;
    }

    inline void setValue(string &key, Expression* expression) {
        //pathMap[key] = val;
    }

    inline double getValue(const string &key) {
        //return pathMap[key];
    }

    inline bool atTable(string &key) {
        return pathMap.find(key) != pathMap.end();
    }
};

#endif //PROJECT_COMMANDTABLE_H
