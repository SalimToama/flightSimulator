//
// Created by issa on 12/17/18.
//
#pragma once

#ifndef PROJECT_DATACOMMAND_H
#define PROJECT_DATACOMMAND_H


#include "Command.h"

class dataCommand : public Command {
protected:
    vector<string>::iterator it;
protected:
    dataCommand(vector<string>::iterator &it);
    void nextIterator();
    string getString();
};


#endif //PROJECT_DATACOMMAND_H
