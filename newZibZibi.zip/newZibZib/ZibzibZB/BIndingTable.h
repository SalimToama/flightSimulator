//
// Created by issa on 12/20/18.
//
#pragma once

#ifndef PROJECT_BINDINGTABLE_H
#define PROJECT_BINDINGTABLE_H
using namespace std;

#include <map>
#include <string>
class BIndingTable {
    map<string, string> bindMap;
    static BIndingTable *map_instance;
public:
    static inline BIndingTable *instance() {
        if (map_instance == nullptr) {
            map_instance = new BIndingTable();
        }
        return map_instance;
    }

    inline void setValue(string &key, string val) {
        bindMap[key] = val;
    }

    inline string getValue(const string &key) {
        map<string, string>::iterator i = bindMap.find(key);
        if (i == bindMap.end())
            return "";
        return i->second;
    }
    inline map<string, string> &getMap() {
        return bindMap;
    }
    inline bool atTable(string &key) {
        return bindMap.find(key) != bindMap.end();
    }
};


#endif //PROJECT_BINDINGTABLE_H
