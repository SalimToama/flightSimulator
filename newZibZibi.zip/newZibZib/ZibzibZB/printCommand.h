//
// Created by issa on 12/12/18.
//
#pragma once

#ifndef PROJECT_PRINTCOMMAND_H
#define PROJECT_PRINTCOMMAND_H

#include <vector>
#include <map>
#include "Command.h"

using namespace std;

class printCommand : public Command {
    vector<string>::iterator &iterator1;
public:
    printCommand(vector<string>::iterator &iterator1);
    int doCommand(vector<string> &text, int index);
};


#endif //PROJECT_PRINTCOMMAND_H
