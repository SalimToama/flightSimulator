#include "CommandExpression.h"

CommandExpression::CommandExpression(vector<string> &linesFromText, Command *command) : linesFromText(
        linesFromText), command(command) {}

double CommandExpression::calculate() {
    return this->command->doCommand(linesFromText,index);
}

CommandExpression::~CommandExpression() {
    delete command;
}




