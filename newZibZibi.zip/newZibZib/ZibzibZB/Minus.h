//
// Created by issa on 12/10/18.
//
#pragma once


#ifndef PROJECT_MINUS_H
#define PROJECT_MINUS_H


#include "BinaryExpression.h"

class Minus : public BinaryExpression{
public:
    Minus(Expression* left, Expression *right);
    ~Minus();
    double calculate();
};


#endif //PROJECT_MINUS_H
