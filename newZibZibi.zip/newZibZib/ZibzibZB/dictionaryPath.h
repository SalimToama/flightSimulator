//
// Created by issa on 12/20/18.
//
#pragma once

#ifndef PROJECT_DICTIONARYPATH_H
#define PROJECT_DICTIONARYPATH_H

#include <map>

using namespace std;

class dictionaryPath {
    map<string, double> pathMap;
    static dictionaryPath *map_instance;
public:
    static inline dictionaryPath *instance() {
        if (map_instance == nullptr) {
            map_instance = new dictionaryPath();
        }
        return map_instance;
    }

    inline void setValue(string &key, double val) {
        pathMap[key] = val;
    }
    inline map<string, double > &getMap() {
        return pathMap;
    }
    inline double getValue(const string &key) {
        return pathMap[key];
    }
    ~dictionaryPath(){
        delete map_instance;
    }
    inline bool atTable(string &key) {
        return pathMap.find(key) != pathMap.end();
    }
};


#endif //PROJECT_DICTIONARYPATH_H
