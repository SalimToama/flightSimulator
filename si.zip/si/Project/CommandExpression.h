#pragma once
#ifndef PROJECT_COMMANDEXPRESSION_H
#define PROJECT_COMMANDEXPRESSION_H

#include <vector>
#include "Expression.h"
#include "Command.h"
class CommandExpression : public Expression{
protected:
    vector<string> linesFromText;
    Command *command;
    int index;
public:
    CommandExpression(const vector<string> &linesFromText, Command *command);
    //void setIndex(int index);
    virtual double calculate();
};


#endif //PROJECT_COMMANDEXPRESSION_H
