//
// Created by issa on 12/18/18.
//
#pragma once

#ifndef PROJECT_EXTRACTEXPRESSION_H
#define PROJECT_EXTRACTEXPRESSION_H
#pragma once
using namespace std;
#include <vector>
#include <string>
#include <list>
#include <map>
#include "SymbolTable.h"
#include "ShuntingYard.h"

class extractExpression {
public:
    static Expression *extract(vector<string>::iterator &iter, vector<string> &vec);

    static bool isCommand(string str);
};


#endif //PROJECT_EXTRACTEXPRESSION_H