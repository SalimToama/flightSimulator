#pragma once
#ifndef PROJECT_OPENSERVERCOMMAND_H
#define PROJECT_OPENSERVERCOMMAND_H

#include "Command.h"
#include "dataBase.h"
#include "dataCommand.h"
#include "extractExpression.h"
#include "DataReaderServer.h"

//#include <thread>
class OpenServerCommand: public Command {
    vector<string>::iterator &iterator1;
public:

    OpenServerCommand(vector<string>::iterator &iter);

    int doCommand(vector<string> text,int i);
};



#endif //PROJECT_OPENSERVERCOMMAND_H
