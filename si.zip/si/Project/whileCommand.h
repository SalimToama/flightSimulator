#pragma once

#ifndef PROJECT_WHILECOMMAND_H
#define PROJECT_WHILECOMMAND_H

#include "conditionParser.h"
#include <vector>
/*
class whileCommand : public conditionParser{
    vector<string>::iterator &iterator1;
public:

    whileCommand(
            vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1);

    int doCommand(vector<string> text,int index);

};

*/
#endif //PROJECT_WHILECOMMAND_H
