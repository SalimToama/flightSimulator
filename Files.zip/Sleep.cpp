//
// Created by issa on 12/16/18.
//

#include "Sleep.h"

int Sleep::doCommand(vector<string> text, int index) {
    sleep(static_cast<unsigned int>(stoi(*iterator1))/1000);
    *iterator1++;
    return 0;
}
