#include "ConnectCommand.h"
#include "ClientServer.h"
#include "DataReaderServer.h"
#include "extractExpression.h"

int ConnectCommand::doCommand(vector<string> text, int index) {
    // Currently stands on connect.
    string ip = "";
    double port = 0;
    ip = *(++iterator1);
    iterator1++;
    // Now stands on the port expression part.
    port =  extractExpression::extract(this->iterator1, text, allMaps->getSymbolTable())->calculate();//TODO make function in DataReaderServer ( call it openServer and give the parameter).
    thread threadClient(ClientServer(),ip,port,allMaps);
    threadClient.detach();
}

ConnectCommand::ConnectCommand(vector<string>::iterator &iterator1, dataBase *allMaps) : iterator1(iterator1), allMaps(allMaps) {}
