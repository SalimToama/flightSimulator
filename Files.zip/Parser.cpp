#include <regex>
#include "Parser.h"
#include "dataCommand.h"
#include "extractExpression.h"

#define command 0

Parser::Parser(vector<string> &text) : toInterpret(text) {
    this->it = this->toInterpret.begin();
}

/*
bool Parser::existsInSymbols(string st){
    map<string, double> map1 = this->allTheMaps->getSymbolTable();
    for (map<string, double>::iterator iterator1 = map1.begin();  iterator1 != map1.end(); iterator1++){
        if (iterator1->first == st)
            return true;
    }
    return false;
}
 */
void Parser::createCommand() {
    this->allTheMaps = new dataBase();
    this->allTheMaps->setCommandTable("openDataServer",
                                      new CommandExpression(toInterpret, new OpenServerCommand(it, allTheMaps)));
    //this->allTheMaps->setCommandTable("connect",
    // new CommandExpression(toInterpret, new ConnectCommand(it, allTheMaps)));
    //this->allTheMaps->setCommandTable("var",new CommandExpression(toInterpret,new DefineVarCommand(it,allTheMaps)));
    //this->allTheMaps->setCommandTable("print",new CommandExpression(toInterpret,new printCommand(allTheMaps->getSymbolTable(),it)));
    //this->allTheMaps->setCommandTable("print", new CommandExpression(toInterpret,new printCommand(allTheMaps->getSymbolTable(),it)));
    //this->allTheMaps->setCommandTable("if", new CommandExpression(toInterpret,new ifCommand(it)));
    split();
}

void Parser::split() {
    int i = 0;
    int j = 0;
    /*
    ++it;
    ++it;
    ++it;
    ++it;
    ++it;
    ++it;
     */
    while (it != this->toInterpret.end()) {
        Expression *expression;
        // if symbol instead of command var, assign the define command.
        if (allTheMaps->symbolExists(*it))
            expression = this->allTheMaps->getCommandTable().find("var")->second;
        else
            expression = this->allTheMaps->getCommandTable().find(*it)->second;
        if (expression != nullptr) {
            expression->calculate();
        }
        j++;
        if (j == 1) {
            while (true) {
                if (i % 1000000000 == 0) {
                }
                i++;
            }
        }
    }
}

void Parser::updateSymbolTable() {
    string var = *it++;
    //symbolTable[var] = atoi((*++it).c_str());
    *it++;
}
/*
for (int i = 0; i < toInterpret.size(); i++) {

}
 */
