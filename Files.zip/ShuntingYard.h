//
// Created by issa on 12/13/18.
//

#ifndef PROJECT_SHUNTINGYARD_H
#define PROJECT_SHUNTINGYARD_H
#include <iostream>
#include <sstream>
#include <stack>
#include <cstdlib>
#include "Expression.h"
#include "Expression.h"
#include "Plus.h"
#include "Minus.h"
#include "Div.h"
#include "Mul.h"

using namespace std;
class ShuntingYard {
public:
    static bool isLeftParen(char ch);
    static bool isRightParen(char ch);
    static Expression* calc(Expression *left, Expression *right, char op);
    static bool isOperator(char ch);
    static bool isNumber(char ch);
    static int precedence(char op);
    static string toString(int num);
    static string toPostfix(string str);
    static void stackOperations(char op, string &output, stack<char> &stack1);
    static Expression* evaluate(string str);
    static bool moreThan2(stack<Expression*> s);
};


#endif //PROJECT_SHUNTINGYARD_H
