
#include "ShuntingYard.h"
#include "Number.h"

bool ShuntingYard::isLeftParen(char ch) {
    return ch == '(';
}

bool ShuntingYard::isRightParen(char ch) {
    return ch == ')';
}

Expression *ShuntingYard::calc(Expression *left, Expression *right, char op) {
    switch (op) {
        case '+':
            return new Plus(left, right);
        case '-':
            return new Minus(left, right);
        case '*':
            return new Mul(left, right);
        case '/':
            return new Div(left, right);
        default:
            throw "Invalid Operator.";
    }
}

bool ShuntingYard::isOperator(char ch) {
    switch (ch) {
        case '+':
            return true;
        case '-':
            return true;
        case '*':
            return true;
        case '/':
            return true;
        default:
            return false;
    }
}

bool ShuntingYard::isNumber(char ch) {
    return !(ch < '0' || ch > '9');
}

int ShuntingYard::precedence(char op) {
    switch (op) {
        case '(':
            return 0;
        case '+':
            return 1;
        case '-':
            return 1;
        case '*':
            return 2;
        case '/':
            return 2;
        case ')':
            return 3;
        default:
            return -1;
    }
}

string ShuntingYard::toString(int num) {
    ostringstream ss;
    ss << num;
    return ss.str();
}

void ShuntingYard::stackOperations(char op, string &output, stack<char> &stack1) {
    char popped;
    ostringstream ss;
    ss << output;
    int pre = precedence(op);
    if (pre == 0) {
        stack1.push(op);
        return;
    }
    if (pre == 3) {
        while (!stack1.empty()) {
            popped = stack1.top();
            stack1.pop();
            if (popped == '(') {
                output = ss.str();
                return;
            }
            if (!ss.str().empty())
                ss << " ";
            ss << popped;
        }
        throw "Invalid Expression.";
    } else {
        while (!stack1.empty()) {
            if (precedence(stack1.top()) < precedence(op)) {
                // found the proper place.
                break;
            }
            popped = stack1.top();
            stack1.pop();
            ss << " " << popped;
        }
        stack1.push(op);
        output = ss.str();
        return;
    }
}

string ShuntingYard::toPostfix(string str) {
    stack<char> stack1;
    string output;
    for (int i = 0; i < str.length(); i++) {
        // Spaces.
        if (str[i] == ' ')
            continue;
        // Numbers.
        if (isNumber(str[i])) {
            if (!output.empty())
                output.append(" ");
            while (i != str.length() && str[i] != ' ') {
                output.append(1, str[i]);
                i++;
            }
            i--;
            continue;
        }
        // Operators.
        if (isOperator(str[i]) || isLeftParen(str[i]) || isRightParen(str[i]))
            stackOperations(str[i], output, stack1);

    }
    while (!stack1.empty()) {
        ostringstream ss;
        ss << stack1.top();
        stack1.pop();
        if (!output.empty())
            output.append(" ");
        output.append(ss.str());
    }
    return output;
}

bool ShuntingYard::moreThan2(stack<Expression *> s) {
    int counter = 0;
    while (!s.empty() && counter != 2) {
        s.pop();
        counter++;
    }
    return counter == 2;
}

Expression *ShuntingYard::evaluate(string str) {
    str = toPostfix(str);
    stack<Expression *> stack1;
    for (int i = 0; i < str.length(); i++) {
        // Spaces.
        if (str[i] == ' ')
            continue;
        // Numbers.
        if (isNumber(str[i])) {
            string num;
            while (i != str.length() && str[i] != ' ') {
                ostringstream ss;
                ss << str[i];
                num.append(ss.str());
                i++;
            }
            stack1.push(new Number(stoi(num)));
            i--;
            continue;
        }
        // Operators.
        if (isOperator(str[i])) {
            if (!moreThan2(stack1))
                throw "Invalid Number of Elements.";
            Expression *right = stack1.top();
            stack1.pop();
            Expression *left = stack1.top();
            stack1.pop();
            stack1.push(calc(left, right, str[i]));
        }
    }
    if (stack1.empty())
        throw "Invalid Number of Elements.";
    return stack1.top();
}
