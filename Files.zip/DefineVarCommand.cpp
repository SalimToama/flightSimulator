//
// Created by issa on 12/10/18.
//

#include "DefineVarCommand.h"
#include "extractExpression.h"

/*
DefineVarCommand::DefineVarCommand(map<string, double> &symbolTable, map<string, string> &bindingTable,
                                   vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char>>>>::iterator &iterator1)
        : symbolTable(symbolTable), bindingTable(bindingTable), iterator1(iterator1) {}
*/


int DefineVarCommand::doCommand(vector<string> text, int index) {
    if (*iterator1 == "var") { // if stands on 'var'
        iterator1++;
        this->allTheMaps->setSymbolTable(*iterator1, 0);
    }
    string var = *iterator1; // stands on var name.
    iterator1++; // Now either stands on '=' or on the next command.
    if (*iterator1 == "=") {
        iterator1++; // Now stands on the expression part.
        this->allTheMaps->setSymbolTable(var, extractExpression::extract(iterator1, text,
                                                                         this->allTheMaps->getSymbolTable())->calculate());
    }
    return 0;
    // Currently irrelevant.
    /*
    while (*iterator1 != "bind") {
        ++iterator1;
    }
    this->allTheMaps->setBindingMap(var, *++iterator1);
     */
    return 0;
}

DefineVarCommand::DefineVarCommand(
        vector<string>::iterator &iterator1, dataBase *allTheMaps) : iterator1(iterator1), allTheMaps(allTheMaps) {}
