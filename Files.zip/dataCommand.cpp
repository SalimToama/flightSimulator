//
// Created by issa on 12/17/18.
//

#include "dataCommand.h"

void dataCommand::nextIterator() {
    this->it++;
}
dataCommand::dataCommand(vector<string>::iterator &it) {
    this->it = it;
}

string dataCommand::getString() {
    return *it;
}
