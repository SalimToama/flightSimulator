#include <iostream>
#include <fstream>
#include <vector>
#include "Parser.h"
#include "ShuntingYard.h"
#include "lexer.h"

#define INSTRUCTIONS "test"
using namespace std;

int main() {
    auto *lexer1 = new lexer();
    vector<string> sender = lexer1->lexerToTextFile(INSTRUCTIONS);
    auto *parser = new Parser(sender);
    parser->createCommand();
}








/*
vector<string> lexer(const string &text) {
    vector<string> lines;
    fstream file;
    string lineFromText;
    if (!file.is_open()) {
        file.open(text, fstream::app | fstream::in);
    }
    while (file >> lineFromText) {
        lines.push_back(lineFromText);
    }
    file.close();
    return lines;
}
*/
