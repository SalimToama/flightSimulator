//
// Created by issa on 12/10/18.

#include "OpenServerCommand.h"
#include "DataReaderServer.h"
#include "extractExpression.h"

using namespace std;

OpenServerCommand::OpenServerCommand(vector<string>::iterator &iter, dataBase *allMaps) : iterator1(iter), allMaps(allMaps) {}

int OpenServerCommand::doCommand(vector<string> &text, int index) {
    double port = 0, hertz = 0;
    this->iterator1++;
    port = extractExpression::extract(iterator1, text, allMaps->getSymbolTable())->calculate();
    hertz = extractExpression::extract(iterator1, text, allMaps->getSymbolTable())->calculate();
    //*++iterator1;
    thread threadServer(DataReaderServer(),port,hertz,allMaps);
    threadServer.detach();
    return 0;
}
