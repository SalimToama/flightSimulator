#include <iostream>
#include <fstream>
#include <vector>
#include "Parser.h"
#include "ShuntingYard.h"
#include "lexer.h"
#include "dictionaryPath.h"
#include "SymbolTable.h"
#include "BIndingTable.h"

#define INSTRUCTIONS "test"
using namespace std;
dictionaryPath* dictionaryPath::map_instance = NULL;
SymbolTable* SymbolTable::map_instance = NULL;
BIndingTable* BIndingTable::map_instance = NULL;
int main() {
    auto *lexer1 = new lexer();
    vector<string> sender = lexer1->lexerToTextFile(INSTRUCTIONS);
    auto *parser = new Parser(sender);
    parser->createCommand();
}








/*
vector<string> lexer(const string &text) {
    vector<string> lines;
    fstream file;
    string lineFromText;
    if (!file.is_open()) {
        file.open(text, fstream::app | fstream::in);
    }
    while (file >> lineFromText) {
        lines.push_back(lineFromText);
    }
    file.close();
    return lines;
}
*/
