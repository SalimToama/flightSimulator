#pragma once

#ifndef PROJECT_SYMBOLTABLE_H
#define PROJECT_SYMBOLTABLE_H

#endif //PROJECT_SYMBOLTABLE_H

#include <string>
#include <map>

using namespace std;

class SymbolTable {
    map<string, double> symbolMap;
    static SymbolTable *map_instance;
public:
    static inline SymbolTable *instance() {
        if (map_instance == nullptr) {
            map_instance = new SymbolTable();
        }
        return map_instance;
    }

    inline map<string, double> &getMap() {
        return symbolMap;
    }

    inline void setValue(const string &key, double val) {
        symbolMap[key] = val;
    }

    inline double getValue(const string &key) {
        map<string, double >::iterator i = symbolMap.find(key);
        if (i == symbolMap.end())
            return 0;
        return i->second;
    }
    inline bool atTable(string &key) {
        return symbolMap.find(key) != symbolMap.end();
    }
    inline map<string, double>::iterator getBegin() {
        return symbolMap.begin();
    }

    inline map<string, double>::iterator getEnd() {
        return symbolMap.end();
    }
};