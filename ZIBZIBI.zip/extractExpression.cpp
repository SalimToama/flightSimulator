//
// Created by issa on 12/18/18.
//

#include "extractExpression.h"

Expression *extractExpression::extract(vector<string>::iterator &it, vector<string> &vec) {
    map<string,double > symbols = SymbolTable::instance()->getMap();
    int counter = 1;
    vector<string> ls;
    ostringstream ss;
    //vector<string>::iterator it = vec.begin();
    int brac = 0;
    while (it != vec.end()) {
        if (isCommand(*it))
            break;
        // Numbers.
        if (ShuntingYard::isNumber(it->at(0))) {
            if (counter != 0) {
                ss << " " << *it;
                if (brac == 0)
                    counter--;
                it++;
                continue;
            }
            break;
        }
        // Brackets.
        if (ShuntingYard::isRightParen(it->at(0))) {
            brac--;
            if (brac == 0) {
                counter--;
            }
            ss << " " << *it;
            it++;
            continue;
        }
        if (ShuntingYard::isLeftParen(it->at(0))) {
            if (counter == 0)
                break;
            brac++;
            ss << " " << *it;
            it++;
            continue;
        }
        // Operators.
        if (ShuntingYard::isOperator(it->at(0))) {
            if (!brac)
                counter++;
            ss << " " << *it;
            it++;
            continue;
        }
            // Vars.
        else {
            if (counter) {
                ss << " " << to_string(symbols[*it]);
                if (!brac)
                    counter--;
                it++;
                continue;
            }
            break;
        }
    }
    string str = ss.str();
    str.erase(0, 1);
    return ShuntingYard::evaluate(str);
}

bool extractExpression::isCommand(string str) {
    if (str == "connect" || str == "var" || str == "openDataServer" || str == "print" || str == "sleep" ||
        str == "while"
        || str == "if") {
        return true;
    }
}