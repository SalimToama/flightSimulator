//
// Created by issa on 12/10/18.
#include "OpenServerCommand.h"


using namespace std;

OpenServerCommand::OpenServerCommand(vector<string>::iterator &iter) : iterator1(iter) {}

int OpenServerCommand::doCommand(vector<string> text, int index) {
    double port = 0, hertz = 0;
    this->iterator1++;
    port = extractExpression::extract(iterator1, text)->calculate();
    hertz = extractExpression::extract(iterator1, text)->calculate();
    //*++iterator1;
    thread threadServer(DataReaderServer(),port,hertz);
    threadServer.detach();
    return 0;
}
