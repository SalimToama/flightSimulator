#include "CommandExpression.h"

CommandExpression::CommandExpression(const vector<string> &linesFromText, Command *command) : linesFromText(
        linesFromText), command(command) {}

double CommandExpression::calculate() {
    return this->command->doCommand(linesFromText,index);
}



