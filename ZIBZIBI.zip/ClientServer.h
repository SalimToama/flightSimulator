//
// Created by issa on 12/15/18.
//
#pragma once

#ifndef PROJECT_CLIENTSERVER_H
#define PROJECT_CLIENTSERVER_H
#include <stdio.h>
#include <stdlib.h>

#include <netdb.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <string>
#include <strings.h>
#include <cstring>
#include "dataBase.h"

using namespace std;

class ClientServer {
public:
    //void openServer(string ip, int port);
    void operator()(string ip, int port);
};


#endif //PROJECT_CLIENTSERVER_H
